```python
import cv2
from matplotlib import pyplot as plt
```


```python
img = cv2.imread('rose.jpg',0)
```


```python
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x17557f5a340>




    
![png](output_2_1.png)
    



```python
histr = cv2.calcHist([img],[0],None,[256],[0,256])
```


```python
plt.plot(histr)
plt.show()
```


    
![png](output_4_0.png)
    



```python

```


```python

```


```python

```


```python

```


```python

```
